package com.ethic.railroute.solution.reader;

import com.ethic.railroute.solution.reader.impl.EdgeStringInputValidator;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class EdgeStringInputValidatorTest {

    @InjectMocks
    EdgeStringInputValidator edgeStringInputValidator;

    @Test
    public void testIfInputEdgeStringIsCorrect() {
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7";
        boolean validate = edgeStringInputValidator.validate(graphEdgeInputString);
        Assert.assertEquals(true, validate);
    }

    @Test
    public void testIfInputEdgeStringHasGibberishSpecialCharacters() {
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,DE6,AD5~CE2,EB3,AE7";
        boolean validate = edgeStringInputValidator.validate(graphEdgeInputString);
        Assert.assertEquals(false, validate);
    }

    @Test
    public void testIfInputEdgeStringHasMultipleGibberishSpecialCharacters() {
        String graphEdgeInputString = "~AB5,BC4,CD8,DC8,DE6,AD5,CE2,^*EB3,AE7";
        boolean validate = edgeStringInputValidator.validate(graphEdgeInputString);
        Assert.assertEquals(false, validate);
    }

    @Test
    //NOTE: This is a valid test case for this interface.
    public void testIfInputEdgeStringHasNoCommas() {
        String graphEdgeInputString = "AB5BC4CD8DC8DE6AD5CE2EB3AE7";
        boolean validate = edgeStringInputValidator.validate(graphEdgeInputString);
        Assert.assertEquals(true, validate);
    }

    @Test
    public void testIfInputEdgeStringHasNoCommasAndOneSpecialCharacter() {
        String graphEdgeInputString = "AB5BC4CD8DC8|DE6AD5CE2EB3AE7";
        boolean validate = edgeStringInputValidator.validate(graphEdgeInputString);
        Assert.assertEquals(false, validate);
    }

    @Test
    public void testIfInputEdgeStringHasCommasAndExtraSpaces() {
        String graphEdgeInputString = "AB5 ,BC4,CD8,DC8,DE6 ,AD5,CE2,EB3,AE7 ";
        boolean validate = edgeStringInputValidator.validate(graphEdgeInputString);
        Assert.assertEquals(true, validate);
    }

    @Test
    public void testIfInputEdgeStringHasCommasAndExtraSpacesAndLowerCaseCharacters() {
        String graphEdgeInputString = "aB5 ,BC4,CD8,DC8,DE6 ,Ad5,CE2,EB3,AE7 ";
        boolean validate = edgeStringInputValidator.validate(graphEdgeInputString);
        Assert.assertEquals(true, validate);
    }

    @Test
    public void testIfInputEdgeStringHasCommasAndExtraSpacesAndLargerDistances() {
        String graphEdgeInputString = "aB5 ,BC4,CD8,DC8,DE6 ,Ad500,CE2,EB3,AE7 ";
        boolean validate = edgeStringInputValidator.validate(graphEdgeInputString);
        Assert.assertEquals(true, validate);
    }

    @Test
    public void testIfValidateMessageIsCorrect() {
        String errorMessage = edgeStringInputValidator.getValidationErrorMessage();
        Assert.assertEquals("EdgeStringInputValidator Found Characters other than ALPHABETS, NUMBERS and COMMA", errorMessage);
    }
}
