package com.ethic.railroute.solution.reader;

import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.RailRoadUtils;
import com.ethic.railroute.solution.reader.impl.EdgeStringInputValidator;
import com.ethic.railroute.solution.reader.impl.GraphEdgesStringInputReader;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class GraphEdgesStringInputReaderTest {

    @InjectMocks
    private GraphEdgesStringInputReader graphEdgesStringInputReader;

    @Mock
    private EdgeStringInputValidator edgeStringInputValidator;

    @Rule
    public ExpectedException exceptionRule = ExpectedException.none();

    @Test
    public void testValidHasEdgesScenario() throws EdgeCreationException, GraphEdgeInputReaderException {
        String graphEdgeInputString = "AB5,BC4,CD8,DC80,DE6,AD5,CE2,EB3,AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
        Assert.assertNotNull(edgeList);
    }

    @Test
    public void testValidHasEdgesScenarioWithValidEdgeCount() throws EdgeCreationException, GraphEdgeInputReaderException {
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
        int edgeCount = 9;
        Assert.assertEquals(edgeCount, edgeList.size());
    }

    @Test
    public void testValidHasEdgesScenarioWithValidFirstEdge() throws EdgeCreationException, GraphEdgeInputReaderException {
        String graphEdgeInputString = "AB50 ,BC4,CD8,DC8,DE6,AD5,CE2,EB3 ,AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
        Edge actualEdge = edgeList.get(0);
        Node startTown = new Node("A");
        Node destTown = new Node("B");
        Edge expectedFirstEdge = RailRoadUtils.createEdge(startTown, destTown, 50);
        Assert.assertEquals(expectedFirstEdge, actualEdge);
    }

    @Test
    public void testInValidScenarioWithAdditionalIncorrectInformationOnAnEdge() throws EdgeCreationException, GraphEdgeInputReaderException {
        exceptionRule.expect(EdgeCreationException.class);
        exceptionRule.expectMessage("The input String at index = 6 does not have start-dest-dist combination");
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,DE6,ADC50,CE2,EB3,AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
    }

    @Test
    public void testInValidScenarioWithLessInformationOnAnEdge() throws EdgeCreationException, GraphEdgeInputReaderException {
        exceptionRule.expect(EdgeCreationException.class);
        exceptionRule.expectMessage("The input String at index = 5 does not have start-dest-dist combination");
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,D6,AD5,CE2,EB3,AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
    }

    @Test
    public void testInValidScenarioWithDistanceHugeForAnEdgeAE() throws EdgeCreationException, GraphEdgeInputReaderException {
        exceptionRule.expect(EdgeCreationException.class);
        exceptionRule.expectMessage("The input String at index = 9 has Distance greater than Integer.MAXVALUE");
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7777777777777777777777777777777777777777777777";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
    }


    @Test(expected = GraphEdgeInputReaderException.class)
    public void testReadIncorrectInputWithMissingCommaSeparator() throws EdgeCreationException, GraphEdgeInputReaderException {
        String graphEdgeInputString = "AB5BC4CD8DC8DE6AD5CE2EB3AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
    }

    @Test(expected = GraphEdgeInputReaderException.class)
    public void testReadIncorrectInputWithInvalidCharacter() throws EdgeCreationException, GraphEdgeInputReaderException {
        String graphEdgeInputString = "AB5BC4CD8DC`8DE6AD5CE2EB3AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
    }
}
