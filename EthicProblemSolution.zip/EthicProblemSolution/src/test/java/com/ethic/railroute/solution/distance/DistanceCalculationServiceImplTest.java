package com.ethic.railroute.solution.distance;

import com.ethic.railroute.solution.*;
import com.ethic.railroute.solution.distance.impl.DistanceCalculationServiceImpl;
import com.ethic.railroute.solution.graph.GraphBuilderException;
import com.ethic.railroute.solution.graph.impl.MapGraphBuilder;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;
import com.ethic.railroute.solution.reader.impl.EdgeStringInputValidator;
import com.ethic.railroute.solution.reader.impl.GraphEdgesStringInputReader;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class DistanceCalculationServiceImplTest {

    @InjectMocks
    private MapGraphBuilder mapGraphBuilder;

    private DistanceCalculationServiceImpl distanceCalculationService;

    @InjectMocks
    private GraphEdgesStringInputReader graphEdgesStringInputReader;

    @Mock
    private EdgeStringInputValidator edgeStringInputValidator;

    @Rule
    public ExpectedException exceptionRule = ExpectedException.none();


    @Before
    public void setUp() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        Map<Node, Set<Edge>> graph = generateSampleInputGraph();
        distanceCalculationService = new DistanceCalculationServiceImpl(graph);
    }

    @Test
    public void testSimpleRouteDistance() throws DistanceNotCalculatableException, IncorrectRouteInputException {
        int routeDistance = distanceCalculationService.distanceAlongACertainRoute("ABC");
        Assert.assertEquals(9, routeDistance);
    }

    @Test
    public void testAnotherSimpleRouteDistance() throws DistanceNotCalculatableException, IncorrectRouteInputException {
        int routeDistance = distanceCalculationService.distanceAlongACertainRoute("ABCDE");
        Assert.assertEquals(23, routeDistance);
    }

    @Test
    public void testAnotherSimpleRouteCircleBackToOnePreviousNodeDistance() throws DistanceNotCalculatableException, IncorrectRouteInputException {
        int routeDistance = distanceCalculationService.distanceAlongACertainRoute("ABCDEB");
        Assert.assertEquals(26, routeDistance);
    }

    @Test(expected = IncorrectRouteInputException.class)
    public void testIncorrectRouteString() throws DistanceNotCalculatableException, IncorrectRouteInputException {
        int routeDistance = distanceCalculationService.distanceAlongACertainRoute("ABCDEB#3");
    }

    @Test(expected = IncorrectRouteInputException.class)
    public void testIncorrectEmptyRouteString() throws DistanceNotCalculatableException, IncorrectRouteInputException {
        int routeDistance = distanceCalculationService.distanceAlongACertainRoute("");
    }

    @Test
    public void testDistanceNotCalculableCaseOne() throws DistanceNotCalculatableException, IncorrectRouteInputException {
        exceptionRule.expect(DistanceNotCalculatableException.class);
        exceptionRule.expectMessage(Constants.NO_SUCH_ROUTE);
        int routeDistance = distanceCalculationService.distanceAlongACertainRoute("AC");
    }

    @Test
    public void testDistanceNotCalculableCaseTwo() throws DistanceNotCalculatableException, IncorrectRouteInputException {
        exceptionRule.expect(DistanceNotCalculatableException.class);
        exceptionRule.expectMessage(Constants.NO_SUCH_ROUTE);
        int routeDistance = distanceCalculationService.distanceAlongACertainRoute("ABCDEC");
    }

    @Test
    public void testDistanceNotCalculableCaseThreeTryingToTraverseToSameTownAgain() throws DistanceNotCalculatableException, IncorrectRouteInputException {
        exceptionRule.expect(DistanceNotCalculatableException.class);
        exceptionRule.expectMessage(Constants.NO_SUCH_ROUTE);
        int routeDistance = distanceCalculationService.distanceAlongACertainRoute("ABCC");
    }

    @Test(expected = IncorrectRouteInputException.class)
    public void testDistanceNotCalculableCaseInputRouteDoesNotExists() throws DistanceNotCalculatableException, IncorrectRouteInputException {
        int routeDistance = distanceCalculationService.distanceAlongACertainRoute("ZABCDEC");
    }


    /**
     * Create a sample input Graph
     *
     * @return
     * @throws EdgeCreationException
     * @throws GraphEdgeInputReaderException
     */
    Map<Node, Set<Edge>> generateSampleInputGraph() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7";
        //String graphEdgeInputString = "AB50 ,BC4,CD8,DC8,DE6,AD5,CE2,EB3 ,AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
        Assert.assertNotNull(edgeList);
        Map<Node, Set<Edge>> graph = mapGraphBuilder.buildGraph(edgeList);
        Assert.assertNotNull(graph);
        return graph;
    }
}