package com.ethic.railroute.solution.route;

import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.IncorrectRouteInputException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.distance.DistanceNotCalculatableException;
import com.ethic.railroute.solution.graph.GraphBuilderException;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;
import com.ethic.railroute.solution.route.impl.ShortestDistanceRouteCalculationService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Map;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class ShortestDistanceRouteCalculationServiceTest extends AbstractGraphGenerator {

    private RouteCalculationService shortestDistanceBasedRouteCalculationService;

    @Before
    public void setUp() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        Map<Node, Set<Edge>> graph = generateSampleInputGraph();
        shortestDistanceBasedRouteCalculationService = new ShortestDistanceRouteCalculationService(graph);
    }

    @Test
    public void testSimpleShortestDistanceBetweenTwoRoutes() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException, EdgeCreationException {
        int shortestRouteBetweenTwoTowns = shortestDistanceBasedRouteCalculationService.findShortestRoute("AC");
        Assert.assertEquals(9, shortestRouteBetweenTwoTowns);
    }

    @Test
    public void testSimpleShortestDistanceBetweenTwoRoutesScenarioOne() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException, EdgeCreationException {
        int shortestRouteBetweenTwoTowns = shortestDistanceBasedRouteCalculationService.findShortestRoute("AE");
        Assert.assertEquals(7, shortestRouteBetweenTwoTowns);
    }

    @Test
    public void testSimpleShortestDistanceBetweenTwoRoutesScenarioTwo() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException, EdgeCreationException {
        int shortestRouteBetweenTwoTowns = shortestDistanceBasedRouteCalculationService.findShortestRoute("AB");
        Assert.assertEquals(5, shortestRouteBetweenTwoTowns);
    }

    @Test
    public void testSimpleShortestDistanceBetweenTwoRoutesScenarioThree() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException, EdgeCreationException {
        int shortestRouteBetweenTwoTowns = shortestDistanceBasedRouteCalculationService.findShortestRoute("AD");
        Assert.assertEquals(5, shortestRouteBetweenTwoTowns);
    }

    @Test
    public void testSimpleShortestDistanceBetweenTwoRoutesScenarioNotNeighbour() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException, EdgeCreationException {
        int shortestRouteBetweenTwoTowns = shortestDistanceBasedRouteCalculationService.findShortestRoute("BE");
        Assert.assertEquals(6, shortestRouteBetweenTwoTowns);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testFindDifferentRoutesNotAvailability() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int shortestDistanceBetweenRoutes = shortestDistanceBasedRouteCalculationService.findDifferentRoutes("CC", 3);
    }
}