package com.ethic.railroute.solution;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class RailRoadUtilsTest {

    @Test
    public void testSimpleSourceAndDestTownCreation() throws IncorrectRouteInputException {
        final SourceTownToDestTown sourceTownToDestTown = RailRoadUtils.createTheRoute("CC");
        Assert.assertEquals(new Node("C"), sourceTownToDestTown.getStartTown());
        Assert.assertEquals(new Node("C"), sourceTownToDestTown.getDestTown());
    }

    @Test
    public void testSimpleEdgeUsingSourceAndDestTowns() throws IncorrectRouteInputException, EdgeCreationException {
        Node a = new Node("A");
        Node b = new Node("b");
        final Edge edge = RailRoadUtils.createEdge(a, b, 10);
        final Edge expectedEdge = new Edge.EdgeBuilder().startTown(a).destTown(b).distance(10).build();
        Assert.assertEquals(expectedEdge, edge);
    }

    @Test
    public void testSimpleEdgeUsingSourceAndDestTownsNotEqual() throws IncorrectRouteInputException, EdgeCreationException {
        Node a = new Node("A");
        Node b = new Node("B");
        Node c = new Node("c");
        final Edge edge = RailRoadUtils.createEdge(a, b, 10);
        final Edge expectedEdge = new Edge.EdgeBuilder().startTown(a).destTown(c).distance(10).build();
        Assert.assertNotEquals(expectedEdge, edge);
    }

    @Test(expected = EdgeCreationException.class)
    public void testSourceNodeNull() throws IncorrectRouteInputException, EdgeCreationException {
        Node a = null;
        Node b = new Node("B");
        final Edge edge = RailRoadUtils.createEdge(a, b, 10);
    }

    @Test(expected = EdgeCreationException.class)
    public void testDestinationNodeNull() throws IncorrectRouteInputException, EdgeCreationException {
        Node a = new Node("A");
        Node b = null;
        final Edge edge = RailRoadUtils.createEdge(a, b, 10);
    }

    @Test(expected = EdgeCreationException.class)
    public void testNegativeWeight() throws IncorrectRouteInputException, EdgeCreationException {
        Node a = new Node("A");
        Node b = new Node("B");
        final Edge edge = RailRoadUtils.createEdge(a, b, -1);
    }

    @Test(expected = IncorrectRouteInputException.class)
    public void testIncorrectSourceAndDestTownCreationWithOnlySource() throws IncorrectRouteInputException {
        final SourceTownToDestTown sourceTownToDestTown = RailRoadUtils.createTheRoute("C");
    }

    @Test(expected = IncorrectRouteInputException.class)
    public void testIncorrectSourceAndDestTownCreationWithMoreInformation() throws IncorrectRouteInputException {
        final SourceTownToDestTown sourceTownToDestTown = RailRoadUtils.createTheRoute("CCC");
    }
}