package com.ethic.railroute.solution.route;

import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.graph.GraphBuilderException;
import com.ethic.railroute.solution.graph.impl.MapGraphBuilder;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;
import com.ethic.railroute.solution.reader.impl.EdgeStringInputValidator;
import com.ethic.railroute.solution.reader.impl.GraphEdgesStringInputReader;
import org.junit.Assert;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Abstract class for generating the graph that the test can utilize
 */
public abstract class AbstractGraphGenerator {

    @InjectMocks
    private MapGraphBuilder mapGraphBuilder;

    @InjectMocks
    private GraphEdgesStringInputReader graphEdgesStringInputReader;

    @Mock
    private EdgeStringInputValidator edgeStringInputValidator;

    /**
     * Create a sample input Graph
     *
     * @return
     * @throws EdgeCreationException
     * @throws GraphEdgeInputReaderException
     */
    protected Map<Node, Set<Edge>> generateSampleInputGraph() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3, AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
        Assert.assertNotNull(edgeList);
        Map<Node, Set<Edge>> graph = mapGraphBuilder.buildGraph(edgeList);
        Assert.assertNotNull(graph);
        return graph;
    }
}