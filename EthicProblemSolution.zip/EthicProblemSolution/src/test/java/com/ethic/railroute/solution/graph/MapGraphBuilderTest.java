package com.ethic.railroute.solution.graph;

import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.graph.impl.MapGraphBuilder;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;
import com.ethic.railroute.solution.reader.impl.EdgeStringInputValidator;
import com.ethic.railroute.solution.reader.impl.GraphEdgesStringInputReader;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class MapGraphBuilderTest {

    @InjectMocks
    private MapGraphBuilder mapGraphBuilder;

    @InjectMocks
    private GraphEdgesStringInputReader graphEdgesStringInputReader;

    @Mock
    private EdgeStringInputValidator edgeStringInputValidator;

    @Test
    public void testValidHasProperGraph() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
        Assert.assertNotNull(edgeList);
        Map<Node, Set<Edge>> graph = mapGraphBuilder.buildGraph(edgeList);
        Assert.assertEquals(5, graph.size());
    }

    @Test
    public void testValidHasProperGraphWithMultipleRepeatedSameNodes() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        String graphEdgeInputString = "AB5,BC40,CD8,DC8,DE6,AD5,CE2,EB3,AE7, AA10,BB5 , CC500";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
        Assert.assertNotNull(edgeList);
        Map<Node, Set<Edge>> graph = mapGraphBuilder.buildGraph(edgeList);
        Assert.assertEquals(5, graph.size());
    }

    @Test
    public void testValidHasProperGraphWithRepeatedEdges() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        String graphEdgeInputString = "AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7,AB15";
        Mockito.when(edgeStringInputValidator.validate(graphEdgeInputString)).thenReturn(true);
        List<Edge> edgeList = graphEdgesStringInputReader.readParameterInputAndConstructEdges(graphEdgeInputString);
        Assert.assertNotNull(edgeList);
        Map<Node, Set<Edge>> graph = mapGraphBuilder.buildGraph(edgeList);
        Assert.assertEquals(5, graph.size());
    }

    @Test(expected = GraphBuilderException.class)
    public void testEmptyGraphForGraphBuilderException() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        List<Edge> edgeList = new ArrayList<>();
        Map<Node, Set<Edge>> graph = mapGraphBuilder.buildGraph(edgeList);
        Assert.assertEquals(0, graph.size());
    }


}