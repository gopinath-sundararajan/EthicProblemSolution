package com.ethic.railroute.solution.route;


import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.IncorrectRouteInputException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.distance.DistanceNotCalculatableException;
import com.ethic.railroute.solution.graph.GraphBuilderException;
import com.ethic.railroute.solution.graph.impl.MapGraphBuilder;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;
import com.ethic.railroute.solution.reader.impl.EdgeStringInputValidator;
import com.ethic.railroute.solution.reader.impl.GraphEdgesStringInputReader;
import com.ethic.railroute.solution.route.impl.DistanceBasedRouteCalculationService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class DistanceBasedRouteCalculationServiceTest extends AbstractGraphGenerator {

    private RouteCalculationService distanceBasedRouteCalculationService;

    @Before
    public void setUp() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        Map<Node, Set<Edge>> graph = generateSampleInputGraph();
        distanceBasedRouteCalculationService = new DistanceBasedRouteCalculationService(graph, RouteCalculationMethodology.ROUTE_DISTANCE_BASED_SEARCH_ALGORITHM);
    }


    @Test
    public void testSimpleDistanceBasedRoutes() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int trips = distanceBasedRouteCalculationService.findDifferentRoutes("CC", 30);
        Assert.assertEquals(7, trips);
    }

    @Test(expected = NoRouteAvailableException.class)
    public void testNoDistanceBasedRoute() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int trips = distanceBasedRouteCalculationService.findDifferentRoutes("CC", 0);
    }

    //We need trips less than max.
    @Test(expected = NoRouteAvailableException.class)
    public void testSimpleDistanceBasedRouteTripDistanceEqualsToMAX() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int trips = distanceBasedRouteCalculationService.findDifferentRoutes("AB", 5);
    }

    @Test
    public void testSimpleDistanceBasedRouteOnlyOneTrip() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int trips = distanceBasedRouteCalculationService.findDifferentRoutes("AB", 6);
        Assert.assertEquals(1, trips);
    }

    @Test
    public void testSimpleDistanceBasedScenarioOne() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int trips = distanceBasedRouteCalculationService.findDifferentRoutes("AE", 24);
        Assert.assertEquals(8, trips);
    }

    @Test
    public void testSimpleDistanceBasedScenarioTwo() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int trips = distanceBasedRouteCalculationService.findDifferentRoutes("ac", 10);
        Assert.assertEquals(1, trips);
    }

    @Test
    public void testSimpleDistanceBasedRouteComplexTrip() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int trips = distanceBasedRouteCalculationService.findDifferentRoutes("AE", 50);
        Assert.assertEquals(72, trips);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testNotSupportedOperationException() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException, EdgeCreationException {
        int trips = distanceBasedRouteCalculationService.findShortestRoute("AE");
    }
}