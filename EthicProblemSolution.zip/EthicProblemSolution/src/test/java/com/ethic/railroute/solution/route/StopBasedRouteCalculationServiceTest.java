package com.ethic.railroute.solution.route;

import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.IncorrectRouteInputException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.distance.DistanceNotCalculatableException;
import com.ethic.railroute.solution.graph.GraphBuilderException;
import com.ethic.railroute.solution.graph.impl.MapGraphBuilder;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;
import com.ethic.railroute.solution.reader.impl.EdgeStringInputValidator;
import com.ethic.railroute.solution.reader.impl.GraphEdgesStringInputReader;
import com.ethic.railroute.solution.route.impl.StopBasedRouteCalculationService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class StopBasedRouteCalculationServiceTest extends AbstractGraphGenerator {

    private RouteCalculationService stopBasedRouteCalculationService;

    @Before
    public void setUp() throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        Map<Node, Set<Edge>> graph = generateSampleInputGraph();
        stopBasedRouteCalculationService = new StopBasedRouteCalculationService(graph, RouteCalculationMethodology.ROUTE_STOP_BASED_SEARCH_ALGORITHM);
    }

    @Test
    public void testSimpleRouteStops() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int stops = stopBasedRouteCalculationService.findDifferentRoutes("CC", 3);
        Assert.assertEquals(2, stops);
    }

    @Test(expected = NoRouteAvailableException.class)
    public void testSimpleRouteZeroStops() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int stops = stopBasedRouteCalculationService.findDifferentRoutes("CC", 0);
    }


    @Test
    public void testSimpleRouteStopsOne() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int stops = stopBasedRouteCalculationService.findDifferentRoutes("AB", 5);
        Assert.assertEquals(8, stops);
    }

    @Test(expected = NoRouteAvailableException.class)
    public void testStartNodeNotInGraph() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int stops = stopBasedRouteCalculationService.findDifferentRoutes("XB", 5);
    }

    @Test(expected = NoRouteAvailableException.class)
    public void testDestNodeNotInGraph() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int stops = stopBasedRouteCalculationService.findDifferentRoutes("BX", 5);
    }

    @Test
    public void testComplexRouteStops() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        int stops = stopBasedRouteCalculationService.findDifferentRoutes("AE", 15);
        Assert.assertEquals(593, stops);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testNotSupportedOperationException() throws DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException, EdgeCreationException {
        int stops = stopBasedRouteCalculationService.findShortestRoute("AE");
    }

}
