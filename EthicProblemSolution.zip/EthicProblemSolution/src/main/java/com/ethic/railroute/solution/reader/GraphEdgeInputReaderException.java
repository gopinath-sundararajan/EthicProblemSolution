package com.ethic.railroute.solution.reader;

/**
 * Exception class for input read exception. This has to be checked Exception.
 */
public class GraphEdgeInputReaderException extends Exception {

    public GraphEdgeInputReaderException(String errorMessage) {
        super(errorMessage);
    }

    public GraphEdgeInputReaderException(String errorMessage, Throwable throwable) {
        super(errorMessage, throwable);
    }
}
