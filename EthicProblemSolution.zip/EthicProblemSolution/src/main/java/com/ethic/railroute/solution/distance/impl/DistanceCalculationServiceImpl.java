package com.ethic.railroute.solution.distance.impl;

import com.ethic.railroute.solution.Constants;
import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.distance.DistanceCalculationService;
import com.ethic.railroute.solution.distance.DistanceNotCalculatableException;
import com.ethic.railroute.solution.IncorrectRouteInputException;

import java.util.*;

/**
 * Distance Calculation Service.
 */
public class DistanceCalculationServiceImpl extends AbstractDistanceCalculationService implements DistanceCalculationService {

    public DistanceCalculationServiceImpl(Map<Node, Set<Edge>> graph) {
        super(graph);
    }

    //TODO for future implementation.
    @Override
    public int distanceBetweenTowns(Node startNode, Node destNode) throws DistanceNotCalculatableException {
        throw new DistanceNotCalculatableException("Not Implemented Currently");
    }

    @Override
    /**
     * Distance along a certain route.
     */
    public int distanceAlongACertainRoute(String route) throws DistanceNotCalculatableException, IncorrectRouteInputException {
        List<Node> routeList = createNodeListForRoute(route.toUpperCase());
        int routeDistance = 0;
        Deque<Node> queue = new ArrayDeque<>();
        //Offer the routeList to Queue to Perform a BFS search.
        for (Node node : routeList) {
            queue.offer(node);
        }
        Map<Node, Set<Edge>> graph = getCurrentGraph();

        while (!queue.isEmpty()) {
            final Node startTown = queue.poll();
            final Set<Edge> edgesFromStart = graph.get(startTown);
            //Town should exists in Graph.
            if (edgesFromStart == null)
                throw new IncorrectRouteInputException(Constants.DESIRED_TOWN_DOES_NOT_EXISTS_IN_GRAPH);
            Node desiredNextStop = null;
            if (!queue.isEmpty()) {
                desiredNextStop = queue.peek();
            }
            if (desiredNextStop == null) return routeDistance;
            //Proceed only if I need to calculation the distance to desiredNextStop.
            boolean foundNextDestination = false;
            for (Edge edge : edgesFromStart) {
                Node destTown = edge.getDestTown();
                if (destTown.equals(desiredNextStop)) {
                    routeDistance += edge.getDistance();
                    foundNextDestination = true;
                    //NO need to look further I found the destination Town.
                    break;
                }
            }
            if (!foundNextDestination) {
                throw new DistanceNotCalculatableException(Constants.NO_SUCH_ROUTE);
            }

        }
        return routeDistance;
    }
}
