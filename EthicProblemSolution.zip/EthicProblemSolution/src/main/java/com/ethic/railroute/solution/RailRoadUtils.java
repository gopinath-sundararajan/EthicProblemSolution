package com.ethic.railroute.solution;

/**
 * Class to host some widely used utility methods. All methods will be static.
 */
public final class RailRoadUtils {

    /**
     * Create Source and Destination Towns from the routeInput.
     *
     * @param routeInput
     * @return
     * @throws IncorrectRouteInputException
     */
    public static SourceTownToDestTown createTheRoute(String routeInput) throws IncorrectRouteInputException {
        checkIfRouteInputStringIsCorrect(routeInput);
        routeInput = routeInput.toUpperCase();
        Node startTown = new Node(Constants.EMPTY_STRING + routeInput.charAt(0));
        Node destTown = new Node(Constants.EMPTY_STRING + routeInput.charAt(1));

        return new SourceTownToDestTown(startTown, destTown);
    }

    /**
     * Create edge.
     *
     * @param sourceTown
     * @param destTown
     * @param distance
     * @return
     * @throws EdgeCreationException
     */
    public static Edge createEdge(Node sourceTown, Node destTown, int distance) throws EdgeCreationException {
        if (sourceTown == null || destTown == null) {
            throw new EdgeCreationException("Source Town or Destination Town cannot be null");
        }
        if (distance < 0) {
            throw new EdgeCreationException("Edge distance cannot be negative");
        }
        Edge edge = new Edge.EdgeBuilder().startTown(sourceTown).destTown(destTown).distance(distance).build();

        return edge;
    }

    /**
     * perform basic routeInput string validation.
     *
     * @param routeInput
     * @throws IncorrectRouteInputException
     */
    public static void checkIfRouteInputStringIsCorrect(String routeInput) throws IncorrectRouteInputException {
        if (routeInput.length() != 2) {
            throw new IncorrectRouteInputException("Only two Characters are allowed in input e.g CC, CB, AB etc");
        }
    }
}
