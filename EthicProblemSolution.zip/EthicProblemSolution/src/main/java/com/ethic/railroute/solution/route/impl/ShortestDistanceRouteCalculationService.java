package com.ethic.railroute.solution.route.impl;

import com.ethic.railroute.solution.*;
import com.ethic.railroute.solution.route.NoRouteAvailableException;
import com.ethic.railroute.solution.route.RouteCalculationService;

import java.util.*;

/**
 * Service to Calculate the Shortest Distance.
 */
public class ShortestDistanceRouteCalculationService implements RouteCalculationService {

    private Map<Node, Set<Edge>> graph;

    /**
     * Constructor for graph input.
     *
     * @param graph
     */
    public ShortestDistanceRouteCalculationService(Map<Node, Set<Edge>> graph) {
        this.graph = graph;
    }

    /**
     * This operation is not currently supported by this service.
     *
     * @param routeInput
     * @param routeCalculationParameter
     * @return
     * @throws IncorrectRouteInputException
     * @throws NoRouteAvailableException
     */
    @Override
    public int findDifferentRoutes(String routeInput, int routeCalculationParameter) throws IncorrectRouteInputException, NoRouteAvailableException {
        throw new UnsupportedOperationException("The Operation is currently unsupported");
    }

    @Override
    public int findShortestRoute(String routeInput) throws IncorrectRouteInputException, NoRouteAvailableException, EdgeCreationException {
        SourceTownToDestTown route = RailRoadUtils.createTheRoute(routeInput);
        Node sourceTown = route.getStartTown();
        Node destTown = route.getDestTown();
        //Keep track of the visited Nodes.
        Set<Node> processedTowns = new HashSet<Node>();

        Map<Node, Integer> edgeDistanceMap = initializeShortestDistanceNodesMap(sourceTown, graph.keySet());
        //Min Heap compare by edge distance.
        Queue<NodeWithDistance> priorityQueue =
                new PriorityQueue<NodeWithDistance>(
                        Comparator.comparing((NodeWithDistance nodeWithDistance) -> nodeWithDistance.getNodeCost()));
        //Offer to the pq
        priorityQueue.offer(new NodeWithDistance(sourceTown, 0));

        while (!priorityQueue.isEmpty()) {
            //If I have processed all the towns break; The below break is very important as there will still be unprocessed elements
            // in the min heap and cannot only depend on priority queue being empty.
            if (processedTowns.size() == graph.keySet().size()) break;

            NodeWithDistance current = priorityQueue.poll();
            final Node currentStartTown = current.getNode();
            if (!processedTowns.contains(currentStartTown)) {
                processedTowns.add(currentStartTown);
                //get the neighbours.
                Set<Edge> edges = graph.get(currentStartTown);
                //Don't proceed if there are no neighbouring towns.
                if (edges != null) {
                    for (Edge edge : edges) {
                        NodeWithDistance neigbhour = new NodeWithDistance(edge.getDestTown(), edge.getDistance());
                        if (!processedTowns.contains(neigbhour)) {
                            int edgeDistanceFromCurrent = edge.getDistance();
                            int newDistance = edgeDistanceMap.get(current.getNode()) + edgeDistanceFromCurrent;
                            int minValue = Math.min(edgeDistanceMap.get(neigbhour.getNode()), newDistance);
                            edgeDistanceMap.put(neigbhour.getNode(), minValue);
                            priorityQueue.offer(new NodeWithDistance(neigbhour.getNode(), minValue));
                        }
                    }
                }
            }
        }

        return edgeDistanceMap.get(destTown);
    }

    /**
     * Initialize the Map with startNode Value of zero and rest of the nodes as Integer.MAX_VALUE
     *
     * @param startNode
     * @param keys
     * @return
     */
    protected Map<Node, Integer> initializeShortestDistanceNodesMap(Node startNode, Set<Node> keys) {
        Map<Node, Integer> shortestDistanceNodeMap = new HashMap<>();
        for (Node node : keys) {
            if (node.equals(startNode)) {
                shortestDistanceNodeMap.put(node, 0);
            } else {
                shortestDistanceNodeMap.put(node, Integer.MAX_VALUE);
            }
        }

        return shortestDistanceNodeMap;
    }

    /**
     * This is the class which keeps tracks of the lowest cost.
     */
    private static class NodeWithDistance {
        private Node node;
        private int nodeCost;

        NodeWithDistance(Node node, int nodeCost) {
            this.node = node;
            this.nodeCost = nodeCost;
        }

        //getter
        Node getNode() {
            return this.node;
        }

        //getter
        int getNodeCost() {
            return this.nodeCost;
        }

        //equals
        public boolean equals(Object obj) {
            if (obj == this) return true;
            if (obj == null) return false;
            if (obj.getClass() != this.getClass()) return false;
            NodeWithDistance nodeWithDistance = (NodeWithDistance) obj;
            return nodeWithDistance.equals(this.getNode()) && nodeWithDistance.getNodeCost() == this.getNodeCost();
        }

        //hashCode
        public int hashCode() {
            int hash = 17;
            hash = 31 * hash + Objects.hash(getNode());
            hash = 31 * hash + getNodeCost();
            return hash;
        }
    }
}