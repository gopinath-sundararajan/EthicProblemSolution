package com.ethic.railroute.solution.distance;

public class DistanceNotCalculatableException extends Exception {
    public DistanceNotCalculatableException(String message) {
        super(message);
    }
}
