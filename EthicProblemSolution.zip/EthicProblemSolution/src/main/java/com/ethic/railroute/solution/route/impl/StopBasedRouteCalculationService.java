package com.ethic.railroute.solution.route.impl;

import com.ethic.railroute.solution.Constants;
import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.IncorrectRouteInputException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.route.RouteCalculationMethodology;
import com.ethic.railroute.solution.route.RouteCalculationService;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * StopBased Route Calculation Service.
 */
public class StopBasedRouteCalculationService extends AbstractBFSBasedRouteCalculationService implements RouteCalculationService {


    /**
     * Initialize graph.
     *
     * @param graph
     */
    public StopBasedRouteCalculationService(Map<Node, Set<Edge>> graph, RouteCalculationMethodology routeCalculationMethodology) {
        super(graph, routeCalculationMethodology);
    }

    /**
     * Static method to get a handle.
     *
     * @param graph
     * @param routeCalculationMethodology
     * @return
     */
    public static RouteCalculationService createStopBasedRouteCalculationService(Map<Node, Set<Edge>> graph, RouteCalculationMethodology routeCalculationMethodology) {
        return new StopBasedRouteCalculationService(graph, routeCalculationMethodology);
    }

    @Override
    protected void raiseExceptionForIncorrectRouteMethodology(RouteCalculationMethodology routeCalculationMethodology)
            throws IncorrectRouteInputException {

        if (routeCalculationMethodology != RouteCalculationMethodology.ROUTE_STOP_BASED_SEARCH_ALGORITHM) {
            StringBuilder builder = new StringBuilder();
            builder.append(Constants.INVALID_ROUTE_METHODOLOGY_TYPE);
            builder.append(" Methodology for DistanceRouteCalculator has to be RoutCalculationType.ROUTE_STOP_BASED_SEARCH_ALGORITHM");
            throw new IncorrectRouteInputException(builder.toString());
        }
    }

    @Override
    protected boolean proceedWithBFS(List<Node> currentList, int calculationParameter) {
        //Source is also part of the list and hence add one to maxStopsAllowed.
        int maxStopsAllowed = calculationParameter + 1;
        if (currentList.size() <= maxStopsAllowed) {
            return true;
        }
        return false;
    }

    /**
     * For stop based implementation no initialization needed.
     */
    @Override
    protected void initialize() {
    }

    /**
     * Stop based implementation currently does not have to inject any settings to satisfy proceedWithBFSCondition();
     *
     * @param existingRoute
     * @param newRoute
     */
    @Override
    protected void injectConditionalParameters(List<Node> existingRoute, List<Node> newRoute, Edge edge) {
    }

}
