package com.ethic.railroute.solution.route;

import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.IncorrectRouteInputException;

/**
 * Route calculation interface .
 */
public interface RouteCalculationService {
    // Find Routes that satisfy the calculation type and the input parameter.

    //No of such routes.
    int findDifferentRoutes(String routeInput, int routeCalculationParameter) throws IncorrectRouteInputException, NoRouteAvailableException;

    //Shortest route between two towns.
    int findShortestRoute(String routeInput) throws IncorrectRouteInputException, NoRouteAvailableException, EdgeCreationException;
}
