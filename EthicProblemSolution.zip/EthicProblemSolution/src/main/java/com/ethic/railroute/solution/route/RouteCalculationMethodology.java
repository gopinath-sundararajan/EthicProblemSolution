package com.ethic.railroute.solution.route;

/**
 * Route Type Calculation Definition.
 */
public enum RouteCalculationMethodology {
    ROUTE_STOP_BASED_SEARCH_ALGORITHM, ROUTE_DISTANCE_BASED_SEARCH_ALGORITHM;
}
