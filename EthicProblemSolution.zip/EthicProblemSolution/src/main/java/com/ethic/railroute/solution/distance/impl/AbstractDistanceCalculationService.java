package com.ethic.railroute.solution.distance.impl;

import com.ethic.railroute.solution.Constants;
import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.IncorrectRouteInputException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Abstract class provides certain default implementation.
 */
public abstract class AbstractDistanceCalculationService {


    Map<Node, Set<Edge>> graph;

    AbstractDistanceCalculationService(Map<Node, Set<Edge>> graph) {
        this.graph = graph;
    }

    /**
     * Node list creation.
     *
     * @param route
     * @return
     */
    List<Node> createNodeListForRoute(String route) throws IncorrectRouteInputException {
        if (route.length() == 0) throw new IncorrectRouteInputException(Constants.EMPTY_ROUTE_INPUT);

        List<Node> routeList = new ArrayList<>();
        char[] chars = route.toCharArray();
        for (char ch : chars) {
            if (!Character.isLetter(ch)) {
                throw new IncorrectRouteInputException(Constants.INVALID_ROUTE_INPUT);
            }
            Node routeNode = new Node(Constants.EMPTY_STRING + ch);
            routeList.add(routeNode);
        }
        return routeList;
    }

    /**
     * The current graph that is analysed.
     *
     * @return
     */
    Map<Node, Set<Edge>> getCurrentGraph() {
        return this.graph;
    }
}
