package com.ethic.railroute.solution.route.impl;

import com.ethic.railroute.solution.*;
import com.ethic.railroute.solution.route.NoRouteAvailableException;
import com.ethic.railroute.solution.route.RouteCalculationMethodology;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Abstract class which provides a structure for GOF Template method pattern.
 */
public abstract class AbstractRouteCalculationService {

    Map<Node, Set<Edge>> graph;
    RouteCalculationMethodology routeCalculationMethodology;

    AbstractRouteCalculationService(Map<Node, Set<Edge>> graph, RouteCalculationMethodology routeCalculationMethodology) {
        this.graph = graph;
        this.routeCalculationMethodology = routeCalculationMethodology;
    }

    /**
     * Base implementation of the interface - RouteCalculationService
     *
     * @param routeInput
     * @param routeCalculationParameter
     * @return
     * @throws IncorrectRouteInputException
     */
    public int findDifferentRoutes(String routeInput, int routeCalculationParameter) throws IncorrectRouteInputException, NoRouteAvailableException {
        List<List<Node>> availableRoutes = findAvailableRoutes(routeInput, routeCalculationParameter);

        return availableRoutes.size();
    }

    /**
     * @param routeInput
     * @param routeCalculationParameter
     * @return
     * @throws IncorrectRouteInputException
     */
    protected List<List<Node>> findAvailableRoutes(String routeInput,
                                                   int routeCalculationParameter)
            throws IncorrectRouteInputException, NoRouteAvailableException {
        //Step-one check if the methodology supplied is correct.
        raiseExceptionForIncorrectRouteMethodology(routeCalculationMethodology);
        //Step-two make sure the routeinput String is valid.
        RailRoadUtils.checkIfRouteInputStringIsCorrect(routeInput);
        //Step-three finally compute the route.
        return computeAvailableRoutes(routeInput, routeCalculationParameter);
    }

    //make sure the methodology supplied is correct.
    protected abstract void raiseExceptionForIncorrectRouteMethodology(RouteCalculationMethodology routeCalculationMethodology)
            throws IncorrectRouteInputException;

    //Template Method.
    protected abstract List<List<Node>> computeAvailableRoutes(String routeInput, int calculationParameter) throws IncorrectRouteInputException, NoRouteAvailableException;


}