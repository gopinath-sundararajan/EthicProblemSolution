package com.ethic.railroute.solution;

import com.ethic.railroute.solution.distance.DistanceCalculationService;
import com.ethic.railroute.solution.distance.DistanceNotCalculatableException;
import com.ethic.railroute.solution.distance.impl.DistanceCalculationServiceImpl;
import com.ethic.railroute.solution.graph.GraphBuilder;
import com.ethic.railroute.solution.graph.GraphBuilderException;
import com.ethic.railroute.solution.graph.impl.MapGraphBuilder;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;
import com.ethic.railroute.solution.reader.impl.EdgeStringInputValidator;
import com.ethic.railroute.solution.reader.impl.GraphEdgesFileInputReader;
import com.ethic.railroute.solution.reader.impl.GraphEdgesStringInputReader;
import com.ethic.railroute.solution.route.NoRouteAvailableException;
import com.ethic.railroute.solution.route.RouteCalculationMethodology;
import com.ethic.railroute.solution.route.RouteCalculationService;
import com.ethic.railroute.solution.route.impl.DistanceBasedRouteCalculationService;
import com.ethic.railroute.solution.route.impl.ShortestDistanceRouteCalculationService;
import com.ethic.railroute.solution.route.impl.StopBasedRouteCalculationService;

import java.io.File;
import java.util.Map;
import java.util.Set;

/**
 * Service to answer typical RailRoad Questions.
 */
public class RailRoadServiceImpl implements RailRoadService {

    //DistanceCalculation Service.
    private DistanceCalculationService distanceCalculationService;

    //Stop based routeCalculation.
    private RouteCalculationService routeCalculationServiceByStops;

    //Distance based routeCalculation.
    private RouteCalculationService routeCalculationServiceByDistance;

    //Shortest Distance based routeCalculation.
    private RouteCalculationService routeCalculationServiceByShortestDistance;


    @Override
    public void inputGraphForAnalysis(final Map<Node, Set<Edge>> graph) {
        distanceCalculationService = new DistanceCalculationServiceImpl(graph);
        routeCalculationServiceByStops = new StopBasedRouteCalculationService(graph, RouteCalculationMethodology.ROUTE_STOP_BASED_SEARCH_ALGORITHM);
        routeCalculationServiceByDistance = new DistanceBasedRouteCalculationService(graph, RouteCalculationMethodology.ROUTE_DISTANCE_BASED_SEARCH_ALGORITHM);
        routeCalculationServiceByShortestDistance = new ShortestDistanceRouteCalculationService(graph);
    }

    @Override
    public void inputGraphForAnalysis(File file) throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException {
        //Decorating the classes to build a graph.
        GraphBuilder graphBuilder = new MapGraphBuilder(new GraphEdgesFileInputReader(new GraphEdgesStringInputReader(new EdgeStringInputValidator())));
        //create the graph
        final Map<Node, Set<Edge>> graph = graphBuilder.buildGraph(file);
        //initialize the services.
        distanceCalculationService = new DistanceCalculationServiceImpl(graph);
        routeCalculationServiceByStops = new StopBasedRouteCalculationService(graph, RouteCalculationMethodology.ROUTE_STOP_BASED_SEARCH_ALGORITHM);
        routeCalculationServiceByDistance = new DistanceBasedRouteCalculationService(graph, RouteCalculationMethodology.ROUTE_DISTANCE_BASED_SEARCH_ALGORITHM);
        routeCalculationServiceByShortestDistance = new ShortestDistanceRouteCalculationService(graph);
    }

    @Override
    /**
     * Using classic GOF delegation pattern using composition.
     * I usually maintain a seperate heierachy at the main service  layer but felt it is a over kill for this exercise.
     *
     * Question-A Distance Along a certain Route.
     */
    public int computeDistanceAlongCertainRoute(String route) throws DistanceNotCalculatableException, IncorrectRouteInputException {
        return distanceCalculationService.distanceAlongACertainRoute(route);
    }

    /**
     * Question-B-One Different routes between towns by Stops
     *
     * @param routeInput
     * @param noOfStops
     * @return
     * @throws NoRouteAvailableException
     * @throws IncorrectRouteInputException
     */
    public int numberOfRoutesBetweenTwoTownsByNoOfStops(String routeInput, int noOfStops) throws NoRouteAvailableException, IncorrectRouteInputException {
        return routeCalculationServiceByStops.findDifferentRoutes(routeInput, noOfStops);
    }

    /**
     * Question-B-Two Different routes between towns by Distance
     *
     * @param routeInput
     * @param maxDistance
     * @return
     * @throws NoRouteAvailableException
     * @throws IncorrectRouteInputException
     */
    public int numberOfRoutesBetweenTwoTownsByDistance(String routeInput, int maxDistance) throws NoRouteAvailableException, IncorrectRouteInputException {
        return routeCalculationServiceByDistance.findDifferentRoutes(routeInput, maxDistance);
    }

    /**
     * Question-C The Shortest route between two towns.
     *
     * @param routeInput
     * @return
     * @throws NoRouteAvailableException
     * @throws IncorrectRouteInputException
     */
    @Override
    public int shortestRouteByDistanceBetweenTwoTowns(String routeInput) throws NoRouteAvailableException, IncorrectRouteInputException, EdgeCreationException {
        return routeCalculationServiceByShortestDistance.findShortestRoute(routeInput);
    }
}