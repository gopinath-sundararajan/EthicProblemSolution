package com.ethic.railroute.solution;

import com.ethic.railroute.solution.distance.DistanceNotCalculatableException;
import com.ethic.railroute.solution.graph.GraphBuilderException;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;
import com.ethic.railroute.solution.route.NoRouteAvailableException;

import java.io.File;

/**
 * Questions that can be asked on RailRoadService.
 */
public class RailRoadServiceQuestions {

    public static void main(String... args) throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException, DistanceNotCalculatableException, IncorrectRouteInputException, NoRouteAvailableException {
        //String input reader.
        File file = new File("D:\\EthicProblemSolution\\src\\main\\resources\\graph_input.txt");
        RailRoadService railRoadService = new RailRoadServiceImpl();
        railRoadService.inputGraphForAnalysis(file);
        //Question-one
        int distanceAlongCertainRoute = railRoadService.computeDistanceAlongCertainRoute("ABC");
        //Question-two(One)
        int stopBasedTrips = railRoadService.numberOfRoutesBetweenTwoTownsByNoOfStops("CC", 3);
        //Question-two(Two)
        int distanceBasedTrips = railRoadService.numberOfRoutesBetweenTwoTownsByDistance("Cc", 30);
        //Question-three
        int shortestRouteByDistanceBetweenTwoTowns = railRoadService.shortestRouteByDistanceBetweenTwoTowns("Cb");

        System.out.println(
                String.format("DistanceAlongCertainRoute is : %d , stopBasedTrips is : %d , " +
                                "distanceBasedTrips is : %d , shortestDistanceBetweenTwoTowns : %d",
                        distanceAlongCertainRoute, stopBasedTrips, distanceBasedTrips, shortestRouteByDistanceBetweenTwoTowns));
    }

}
