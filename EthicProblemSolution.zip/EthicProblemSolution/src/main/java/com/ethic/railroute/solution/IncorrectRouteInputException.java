package com.ethic.railroute.solution;

/**
 * This exception will be raised when the routeInput is incorrect.
 */
public class IncorrectRouteInputException extends Exception {
    public IncorrectRouteInputException(String message) {
        super(message);
    }
}
