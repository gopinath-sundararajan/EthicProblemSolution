package com.ethic.railroute.solution;

/**
 * Class to hold Source To Destination Town.
 */
public class SourceTownToDestTown {

    private Node startTown;
    private Node destTown;

    /**
     * Parameter constructor.
     *
     * @param sourceTown
     * @param destTown
     */
    public SourceTownToDestTown(Node sourceTown, Node destTown) {
        this.startTown = sourceTown;
        this.destTown = destTown;
    }

    //getter
    public Node getStartTown() {
        return this.startTown;
    }

    //getter.
    public Node getDestTown() {
        return this.destTown;
    }

    /**
     * toString() representation of the object.
     *
     * @return
     */
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(getStartTown().getName());
        builder.append(getDestTown().getName());
        return builder.toString();
    }
}
