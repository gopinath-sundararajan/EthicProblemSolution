package com.ethic.railroute.solution.route.impl;

import com.ethic.railroute.solution.Constants;
import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.IncorrectRouteInputException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.route.RouteCalculationMethodology;
import com.ethic.railroute.solution.route.RouteCalculationService;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Distance based RouteCalculation Service.
 */
public class DistanceBasedRouteCalculationService extends AbstractBFSBasedRouteCalculationService implements RouteCalculationService {

    //this is an identity hashmap , key is based on System.identityHashCode().
    Map<List<Node>, Integer> maximumDistanceCoveredMap = new IdentityHashMap<>();

    /**
     * Initiallze the graph that is currently analyzed.
     *
     * @param graph
     */
    public DistanceBasedRouteCalculationService(Map<Node, Set<Edge>> graph, RouteCalculationMethodology routeCalculationMethodology) {
        super(graph, routeCalculationMethodology);
    }

    /**
     * Static method to get a handle.
     *
     * @param graph
     * @param routeCalculationMethodology
     * @return
     */
    public static RouteCalculationService createDistanceBasedRouteCalculationService(Map<Node, Set<Edge>> graph, RouteCalculationMethodology routeCalculationMethodology) {
        return new DistanceBasedRouteCalculationService(graph, routeCalculationMethodology);
    }

    @Override
    protected boolean proceedWithBFS(List<Node> currentList, int calculationParameter) {
        if (!maximumDistanceCoveredMap.containsKey(currentList)) return true;

        int maxTraversedDistanceSoFar = maximumDistanceCoveredMap.get(currentList);
        if (maxTraversedDistanceSoFar < calculationParameter) {
            return true;
        }
        return false;
    }

    @Override
    protected void initialize() {
        maximumDistanceCoveredMap.clear();
    }

    @Override
    protected void injectConditionalParameters(List<Node> exisingRoute, List<Node> newRoute, Edge edge) {
        if (maximumDistanceCoveredMap.containsKey(exisingRoute)) {
            int traversedDistanceSoFar = maximumDistanceCoveredMap.get(exisingRoute);
            maximumDistanceCoveredMap.put(newRoute, traversedDistanceSoFar + edge.getDistance());
        } else {
            maximumDistanceCoveredMap.put(newRoute, edge.getDistance());
        }
    }

    @Override
    protected void raiseExceptionForIncorrectRouteMethodology(RouteCalculationMethodology routeCalculationMethodology) throws IncorrectRouteInputException {
        if (routeCalculationMethodology != RouteCalculationMethodology.ROUTE_DISTANCE_BASED_SEARCH_ALGORITHM) {
            StringBuilder builder = new StringBuilder();
            builder.append(Constants.INVALID_ROUTE_METHODOLOGY_TYPE);
            builder.append(" Methodology for DistanceRouteCalculator has to be RoutCalculationType.ROUTE_DISTANCE_BASED_SEARCH_ALGORITHM");
            throw new IncorrectRouteInputException(builder.toString());
        }
    }
}