package com.ethic.railroute.solution.reader;

import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;

import java.io.File;
import java.util.List;

/**
 * Input reader interface for Graph.
 */
public interface GraphEdgeInputReader {

    public List<Edge> readExternalSourceInputAndConstructEdges(File file) throws GraphEdgeInputReaderException, EdgeCreationException;

    List<Edge> readParameterInputAndConstructEdges(String input) throws GraphEdgeInputReaderException, EdgeCreationException;
}
