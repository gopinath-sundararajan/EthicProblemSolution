package com.ethic.railroute.solution;

/**
 * Exception during Edge Creation. This has to be a checked Exception.
 */
public class EdgeCreationException extends Exception {
    public EdgeCreationException(String exception) {
        super(exception);
    }
}
