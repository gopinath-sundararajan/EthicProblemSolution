package com.ethic.railroute.solution;

/**
 * Constants final class.
 */
public final class Constants {

    public static final String EMPTY_STRING = "";
    public static final String COMMA_STRING = ",";
    public static final String NO_SUCH_ROUTE = "NO SUCH ROUTE";
    public static final String INVALID_ROUTE_INPUT = "Invalid Route input";
    public static final String INVALID_ROUTE_METHODOLOGY_TYPE = "Invalid Route calculation methodology type";
    public static final String EMPTY_ROUTE_INPUT = "EMPTY INPUT ROUTE";
    public static final String DESIRED_TOWN_DOES_NOT_EXISTS_IN_GRAPH = "The Desired Town does not exists in GRAPH";
    public static final char COMMA_CHARACTER = ',';
    public static final char EMPTY_CHARACTER = ' ';
    public static final String SOURCE_TOWN_NOT_FOUND = "Source TOWN is not found in GRAPH";

}