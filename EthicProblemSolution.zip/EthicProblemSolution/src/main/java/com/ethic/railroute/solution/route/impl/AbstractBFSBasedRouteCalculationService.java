package com.ethic.railroute.solution.route.impl;

import com.ethic.railroute.solution.*;
import com.ethic.railroute.solution.route.NoRouteAvailableException;
import com.ethic.railroute.solution.route.RouteCalculationMethodology;

import java.util.*;


/**
 * Provides a BFS graph search implementation which can be leveraged by stops and distance calculation methodologies.
 * I am not breaking the SOLID design principles here as I am only providing a BFS search feature.
 */
public abstract class AbstractBFSBasedRouteCalculationService extends AbstractRouteCalculationService {

    AbstractBFSBasedRouteCalculationService(Map<Node, Set<Edge>> graph, RouteCalculationMethodology routeCalculationMethodology) {
        super(graph, routeCalculationMethodology);
    }

    protected List<List<Node>> computeAvailableRoutes(String routeInput, int calculationParameter) throws IncorrectRouteInputException, NoRouteAvailableException {
        initialize();
        return performBFSSearch(routeInput, calculationParameter);
    }

    /**
     * Perform the bfs search in graph.
     *
     * @param routeInput
     * @return
     */
    protected List<List<Node>> performBFSSearch(String routeInput, int calculationParameter) throws IncorrectRouteInputException, NoRouteAvailableException {
        List<List<Node>> routeCombinations = new ArrayList<>();
        SourceTownToDestTown sourceTownToDestTown = RailRoadUtils.createTheRoute(routeInput);
        Node sourceTown = sourceTownToDestTown.getStartTown();
        Node destTown = sourceTownToDestTown.getDestTown();

        List<Node> startList = new ArrayList<Node>();
        //initialize the seed.
        startList.add(sourceTown);
        //I kind of love BFS but I should use DFS at least some times. May be next time.
        Deque<List<Node>> queue = new LinkedList<>();
        queue.offer(startList);

        while (!queue.isEmpty()) {
            List<Node> current = queue.poll();
            //can only proceed if current list satisfies the proceed criteria
            if (proceedWithBFS(current, calculationParameter)) {
                Node currentTown = current.get(current.size() - 1);
                Set<Edge> edges = graph.get(currentTown);
                //this has to be satisfied at all cost to proceed. Should be good always for file created graph , but may not satisfy the manually created graph.
                //Don't proceed if there are no neighbouring towns
                if (edges != null) {
                    for (Edge edge : edges) {
                        Node currentDestTown = edge.getDestTown();
                        List<Node> tempList = new ArrayList<>(current);
                        tempList.add(currentDestTown);
                        injectConditionalParameters(current, tempList, edge);
                        //Can only proceed if the new created list satisfies the proceed criteria
                        if (proceedWithBFS(tempList, calculationParameter)) {
                            if (currentDestTown.equals(destTown) && tempList.size() > 1) {
                                routeCombinations.add(tempList);
                            }
                            queue.offer(tempList);
                        }
                    }
                }
            }
        }
        if (routeCombinations.size() == 0)
            throw new NoRouteAvailableException(String.format("No such Route(%s)  is available", routeInput));
        return routeCombinations;
    }

    /**
     * Condition to stop the BFS search. again a GOF Template Method pattern.
     *
     * @param currentList
     * @param calculationParameter
     * @return
     */
    protected abstract boolean proceedWithBFS(List<Node> currentList, int calculationParameter);

    /**
     * Initialize any needed parameters.
     */
    protected abstract void initialize();

    /**
     * This method provides a segway to inject additional conditions for subclasses to satisfy the proceedWithBFSCondition() call.
     *
     * @param existingRoute
     * @param newRoute
     */
    protected abstract void injectConditionalParameters(List<Node> existingRoute, List<Node> newRoute, Edge edge);

    /**
     * Find Shortest route is not supported in the BFS based Route calculation Service
     *
     * @param routeInput
     * @return
     * @throws IncorrectRouteInputException
     * @throws NoRouteAvailableException
     */
    public int findShortestRoute(String routeInput) throws IncorrectRouteInputException, NoRouteAvailableException {
        throw new UnsupportedOperationException("This operation is current unSupported ");
    }
}
