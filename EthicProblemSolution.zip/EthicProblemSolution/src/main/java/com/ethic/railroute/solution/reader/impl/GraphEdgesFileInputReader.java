package com.ethic.railroute.solution.reader.impl;

import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.reader.GraphEdgeInputReader;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Classic GOF Decorator pattern implementation will be used to read from File using underlying GraphStringInputReader.
 */
public class GraphEdgesFileInputReader implements GraphEdgeInputReader {

    //Base Function over which I will Decorate.
    private final GraphEdgeInputReader graphEdgeInputReader;

    public GraphEdgesFileInputReader(GraphEdgeInputReader graphInputReader) {
        this.graphEdgeInputReader = graphInputReader;
    }

    @Override
    public List<Edge> readExternalSourceInputAndConstructEdges(File file) throws GraphEdgeInputReaderException, EdgeCreationException {
        List<Edge> edgesForGivenInput = new ArrayList<>();
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String inputString = scanner.nextLine();
                if (inputString.length() > 0) {
                    List<Edge> edgesFromASingleLine = graphEdgeInputReader.readParameterInputAndConstructEdges(inputString);
                    edgesForGivenInput.addAll(edgesFromASingleLine);
                }
            }
        } catch (FileNotFoundException fileNotFoundException) {
            throw new GraphEdgeInputReaderException(fileNotFoundException.getMessage(), fileNotFoundException);
        }
        return edgesForGivenInput;
    }

    @Override
    public List<Edge> readParameterInputAndConstructEdges(String input) throws GraphEdgeInputReaderException, EdgeCreationException {
        return graphEdgeInputReader.readParameterInputAndConstructEdges(input);
    }
}