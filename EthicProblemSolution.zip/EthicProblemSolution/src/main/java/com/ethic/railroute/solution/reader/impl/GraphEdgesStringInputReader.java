package com.ethic.railroute.solution.reader.impl;

import com.ethic.railroute.solution.*;
import com.ethic.railroute.solution.reader.EdgeInputValidator;
import com.ethic.railroute.solution.reader.GraphEdgeInputReader;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Default String Graph parser
 */
public class GraphEdgesStringInputReader implements GraphEdgeInputReader {


    //Validator interface. Can further be provided a default implementation for specific use cases.
    private EdgeInputValidator edgeInputValidator;

    public GraphEdgesStringInputReader(EdgeInputValidator edgeInputValidator) {
        this.edgeInputValidator = edgeInputValidator;
    }


    @Override
    public List<Edge> readParameterInputAndConstructEdges(String input) throws GraphEdgeInputReaderException, EdgeCreationException {
        List<Edge> edgesForGivenInput = new ArrayList<>();

        if (!edgeInputValidator.validate(input)) {
            throw new GraphEdgeInputReaderException(edgeInputValidator.getValidationErrorMessage());
        }

        if (!input.contains(Constants.COMMA_STRING)) {
            throw new GraphEdgeInputReaderException("The input String does not contain COMMA Separator");
        }
        //regex split by ","
        final List<String> edgeList = Stream.of(input.split(Constants.COMMA_STRING, -1)).collect(Collectors.toList());

        //Need to use the classic Iterator pattern to be able to tell if there is an input error on an index.
        //Not using streams here.
        for (int i = 0; i < edgeList.size(); i++) {
            String edge = edgeList.get(i).trim().toUpperCase();
            if (edgeList.get(i).length() < 3) {
                StringBuilder builder = new StringBuilder();
                builder.append(String.format("The input String at index = %d does not have start-dest-dist combination", (i + 1)));
                throw new EdgeCreationException(builder.toString());
            }
            Node startTown = new Node(Constants.EMPTY_STRING + edge.charAt(0));
            Node destTown = new Node(Constants.EMPTY_STRING + edge.charAt(1));
            String dString = edge.substring(2);
            if (checkIfCharactersPresent(dString)) {
                StringBuilder builder = new StringBuilder();
                builder.append(String.format("The input String at index = %d does not have start-dest-dist combination", (i + 1)));
                throw new EdgeCreationException(builder.toString());
            }
            int distance = 0;
            try {
                distance = Integer.valueOf(dString);
            } catch (NumberFormatException numberFormatException) {
                StringBuilder builder = new StringBuilder();
                builder.append(String.format("The input String at index = %d has Distance greater than Integer.MAXVALUE", (i + 1)));
                throw new EdgeCreationException(builder.toString());
            }
            Edge edgeNode = RailRoadUtils.createEdge(startTown, destTown, distance);

            edgesForGivenInput.add(edgeNode);
        }

        return edgesForGivenInput;
    }

    /**
     * check if distance string has any characters.
     *
     * @param distance
     * @return
     */
    public boolean checkIfCharactersPresent(String distance) throws EdgeCreationException {
        char[] chars = distance.toCharArray();
        for (char ch : chars) {
            if (Character.isLetter(ch)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public List<Edge> readExternalSourceInputAndConstructEdges(File file) throws GraphEdgeInputReaderException, EdgeCreationException {
        throw new UnsupportedOperationException("Operation Unsupported");
    }
}
