package com.ethic.railroute.solution.reader.impl;

import com.ethic.railroute.solution.Constants;
import com.ethic.railroute.solution.reader.EdgeInputValidator;

/**
 * EdgeStringInputValidator.
 * Validates that the input is only Alphabets or numbers or "," and no other ascii characters.
 */
public class EdgeStringInputValidator implements EdgeInputValidator {

    @Override
    public boolean validate(String inputString) {
        char[] inputChars = inputString.toUpperCase().toCharArray();

        for (int i = 0; i < inputChars.length; i++) {
            char ch = inputChars[i];
            if (ch == Constants.COMMA_CHARACTER || Character.isLetterOrDigit(ch) || ch == Constants.EMPTY_CHARACTER) {
                continue;
            } else {
                return false;
            }
        }
        return true;
    }

    @Override
    public String getValidationErrorMessage() {
        return "EdgeStringInputValidator Found Characters other than ALPHABETS, NUMBERS and COMMA";
    }
}
