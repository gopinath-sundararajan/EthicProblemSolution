package com.ethic.railroute.solution;

import com.ethic.railroute.solution.distance.DistanceNotCalculatableException;
import com.ethic.railroute.solution.graph.GraphBuilderException;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;
import com.ethic.railroute.solution.route.NoRouteAvailableException;

import java.io.File;
import java.util.Map;
import java.util.Set;

/**
 * Rail Road Service that answers the common question that may rise on
 */
public interface RailRoadService {

    void inputGraphForAnalysis(Map<Node, Set<Edge>> graph);

    void inputGraphForAnalysis(File file) throws EdgeCreationException, GraphEdgeInputReaderException, GraphBuilderException;

    //Ask the below route questions.
    int computeDistanceAlongCertainRoute(String route) throws DistanceNotCalculatableException, IncorrectRouteInputException;

    int numberOfRoutesBetweenTwoTownsByNoOfStops(String routeInput, int noOfStops) throws NoRouteAvailableException, IncorrectRouteInputException;

    int numberOfRoutesBetweenTwoTownsByDistance(String routeInput, int maxDistance) throws NoRouteAvailableException, IncorrectRouteInputException;

    int shortestRouteByDistanceBetweenTwoTowns(String routeInput) throws NoRouteAvailableException, IncorrectRouteInputException, EdgeCreationException;
}
