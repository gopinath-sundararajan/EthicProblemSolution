package com.ethic.railroute.solution.route;

//Exception for No Route Information.
public class NoRouteAvailableException extends Exception {

    public NoRouteAvailableException(String message) {
        super(message);
    }
}
