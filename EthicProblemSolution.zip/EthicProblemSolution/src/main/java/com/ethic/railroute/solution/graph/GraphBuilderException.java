package com.ethic.railroute.solution.graph;

public class GraphBuilderException extends Exception {
    public GraphBuilderException(String exception) {
        super(exception);
    }
}
