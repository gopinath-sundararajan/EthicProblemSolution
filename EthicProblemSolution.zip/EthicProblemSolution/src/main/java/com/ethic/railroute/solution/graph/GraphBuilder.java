package com.ethic.railroute.solution.graph;

import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface GraphBuilder {


    /**
     * graph build method.
     *
     * @param edges
     * @return
     * @throws GraphBuilderException
     */
    Map<Node, Set<Edge>> buildGraph(File file) throws GraphBuilderException, EdgeCreationException, GraphEdgeInputReaderException;

    /**
     * graph build method.
     *
     * @param edges
     * @return
     * @throws GraphBuilderException
     */
    Map<Node, Set<Edge>> buildGraph(List<Edge> edges) throws GraphBuilderException;
}
