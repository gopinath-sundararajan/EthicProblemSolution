package com.ethic.railroute.solution.reader;

/**
 * facilitates Desired Validator for an input.
 */
public interface EdgeInputValidator {

    //Validate method for validation of the inputString.
    boolean validate(String inputString);

    //Expose custom error message that the user wants to see.
    String getValidationErrorMessage();
}
