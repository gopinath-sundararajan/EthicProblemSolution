package com.ethic.railroute.solution.distance;

import com.ethic.railroute.solution.IncorrectRouteInputException;
import com.ethic.railroute.solution.Node;

/**
 * Distance calculation Service will help in two things
 * 1. will tell the distance between two towns
 * 2. will tell the distance on a route
 * 3. If not able to find the distance will throw DistanceNotCalculatableException.
 */
public interface DistanceCalculationService {

    int distanceBetweenTowns(Node startNode, Node destNode) throws DistanceNotCalculatableException;

    /**
     * primary interested question.
     *
     * @param route
     * @return
     * @throws DistanceNotCalculatableException
     */
    int distanceAlongACertainRoute(String route) throws DistanceNotCalculatableException, IncorrectRouteInputException;
}
