package com.ethic.railroute.solution;

import java.io.Serializable;
import java.util.Objects;

/**
 * Representation of the Town(Vertex) as Node.
 */
public class Node implements Serializable {
    //Town Name;
    // The name will not be restricted to just a single Character and hence string.
    private String name;

    /**
     * Node Constructor.
     *
     * @param name
     */
    public Node(String name) {
        this.name = name.toUpperCase();
    }

    /**
     * getter()
     *
     * @return
     */
    public String getName() {
        return this.name;
    }

    /**
     * equals ().
     *
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if ((obj == null) || this.getClass() != obj.getClass()) return false;

        Node node = (Node) obj;
        return node.getName().equals(this.getName());
    }

    /**
     * @return
     */
    @Override
    public int hashCode() {
        return Objects.hash(this.getName());
    }


    /**
     * toString() representation of Node Object.
     *
     * @return
     */
    public String toString() {
        return this.name;
    }
}