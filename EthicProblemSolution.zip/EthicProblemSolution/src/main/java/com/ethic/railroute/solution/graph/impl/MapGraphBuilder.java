package com.ethic.railroute.solution.graph.impl;

import com.ethic.railroute.solution.Edge;
import com.ethic.railroute.solution.EdgeCreationException;
import com.ethic.railroute.solution.Node;
import com.ethic.railroute.solution.graph.GraphBuilder;
import com.ethic.railroute.solution.graph.GraphBuilderException;
import com.ethic.railroute.solution.reader.GraphEdgeInputReader;
import com.ethic.railroute.solution.reader.GraphEdgeInputReaderException;

import java.io.File;
import java.util.*;

/**
 * Map based graph Builder.
 */
public class MapGraphBuilder implements GraphBuilder {

    private GraphEdgeInputReader graphEdgeInputReader;

    public MapGraphBuilder(GraphEdgeInputReader graphEdgeInputReader) {
        this.graphEdgeInputReader = graphEdgeInputReader;
    }


    @Override
    public Map<Node, Set<Edge>> buildGraph(File file) throws GraphBuilderException, EdgeCreationException, GraphEdgeInputReaderException {
        List<Edge> edges = graphEdgeInputReader.readExternalSourceInputAndConstructEdges(file);
        return buildGraph(edges);
    }

    /**
     * Constructs the graph and returns the unmodifiable graph.
     */
    @Override
    public Map<Node, Set<Edge>> buildGraph(List<Edge> edges) throws GraphBuilderException {
        final Map<Node, Set<Edge>> graph = new HashMap<>();

        edges.stream().forEach(edge -> {
            Node startTown = edge.getStartTown();
            Node destTown = edge.getDestTown();
            // We cannot go from same place to same place :) it cannot be part of the edges.
            if (!startTown.equals(destTown)) {
                Set<Edge> adjacencyEdges = graph.getOrDefault(startTown, new HashSet<>());
                //Be aware that the latest edge information will be ignored so the earliest edge distance takes precedence.
                adjacencyEdges.add(edge);
                graph.put(startTown, adjacencyEdges);
            }
        });

        if (graph.isEmpty()) throw new GraphBuilderException("Empty Graph check the edges List");
        //Wanted to use Gauva immutable Map , but wantd to restrain using any third party libraries.
        return Collections.unmodifiableMap(graph);
    }
}
