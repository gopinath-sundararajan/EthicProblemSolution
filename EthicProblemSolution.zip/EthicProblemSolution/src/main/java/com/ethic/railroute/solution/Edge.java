package com.ethic.railroute.solution;

import java.io.Serializable;
import java.util.Objects;

/**
 * Generic Representation of the edge between two towns.
 */
public class Edge implements Serializable {

    //Starting Town.
    private final Node startTown;

    //Destination Town
    private final Node destTown;

    //Distance between two towns.
    // Implicit assumption is the distance <= Integer.MAX_VALUE and positive.
    private final int distance;

    /**
     * Edge Constructor.
     */
    private Edge(EdgeBuilder edgeBuilder) {
        this.startTown = edgeBuilder.startTown;
        this.destTown = edgeBuilder.destTown;
        this.distance = edgeBuilder.distance;
    }

    //Getter for starting Town
    public Node getStartTown() {
        return this.startTown;
    }

    //Getter for Dest Town.
    public Node getDestTown() {
        return this.destTown;
    }

    //Getter for distance.
    public int getDistance() {
        return this.distance;
    }

    /**
     * equals() implementation.
     *
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if ((this == null) || (this.getClass() != obj.getClass())) return false;

        Edge edge = (Edge) obj;
        return this.startTown.equals(edge.startTown) && this.destTown.equals(edge.destTown);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.startTown, this.destTown);
    }

    /**
     * toString() representation of the Edge object.
     *
     * @return
     */
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(getStartTown().getName());
        builder.append(getDestTown().getName());
        builder.append(getDistance());
        return builder.toString();
    }

    /**
     * Edge Builder GOF Builder pattern.
     */
    public static class EdgeBuilder {
        private Node startTown;
        private Node destTown;
        private int distance;

        public EdgeBuilder() {
        }

        public EdgeBuilder startTown(Node startTown) throws EdgeCreationException {
            this.startTown = startTown;
            return this;
        }

        public EdgeBuilder destTown(Node destTown) throws EdgeCreationException {
            this.destTown = destTown;
            return this;
        }

        public EdgeBuilder distance(int distance) throws EdgeCreationException {
            this.distance = distance;
            return this;
        }

        /**
         * quintessential build method.
         *
         * @return
         */
        public Edge build() {
            Edge edge = new Edge(this);
            return edge;
        }
    }
}
