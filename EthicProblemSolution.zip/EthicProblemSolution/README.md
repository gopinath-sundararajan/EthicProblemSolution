<h4>Coding/Design Guidelines</h4>
<ul>
    <li>SOLID design principles will be followed through out the coding example. Pls refer <a href="https://en.wikipedia.org/wiki/SOLID">SOLID DESIGN PRINCIPLES OF DEVELOPMENT</a></li>
    <li>Gang Of Four(GOF) patterns will be used as and when necessary</li>
    <li>BFS(Breadth first search) is given a preferential treatment, but it is a just my personal choice.</li>
</ul>
<h4>References</h4>
<ul>
    <li> Programming Pearls By Jon Bentley</li>
    <li> Introduction to Algorithms By Cormen et.al</li>
    <li> Design Patterns By Eric Gamma et.al</li>
</ul>
<h4> ASSUMPTIONS</h4>
    <ul> 
        <li> The implementation does not have any limitation on the Vertices(Towns) that the graph can hold. 
             The design is flexible to construct the graph as long as the list of edges that are connected with each other 
             are provided. A graph builder is used to construct the graph using the supplied list of edges.
             For validating the algorithm and to simplify the task of validation , the edges construction assume that
             that we are dealing with only 26 cities with a distinct english alphabet representing a distinct town.
             <h6>GraphEdgesStringInputReader.java :- </h6> is once such implementation that takes a raw string of edges and constructs a list of edges.
             <h6>GraphEdgesFileInputReader.java :- </h6>  can read edges of more than 26 towns but is currently 
             DECORATING on the GraphEdgesStringInputReader.java, so it provides only a basic file reader functionality and 
             relies on the underlying String input reader for edge creation, So again we are restricted here to 26 towns.
             This exercise is to demonstrate the taught process and also to demonstrate the design / coding /testing of a simulated use case
        </li>
        <li> The distance between two cities has to less than Integer.MAX_VALUE a four byte primitive int represents the distance between them.</li>
        <li> No negative distances allowed between two cities </li>
        <li> If provided edges where starting and ending towns are same they will be ignored</li>
        <li> One cannot repeat the same edge again with a new distance the latest entry will be ignored as Set is used to represent the adjacency nodes</li>
    </ul>


<h4> PROJECT SETUP.</h4>

This is a maven project, with a few external dependencies (Mockito & Junit) . I refrained from using @lombok/@guava/@commons-util etc and wrote all
the getter/setter/equals/hashcode/toString by myself. The mockito/junit dependencies are included in the POM.xml file.
<br>
Unzip the project. Install Maven if it not in the local computer. Maven 3.6.3 is used to build the project.
<br>
For the ease of the case study the zip provided is an intellij community edition java project, so it  can be extracted
as an IntelliJ project via the community edition.
<br>
if downloading intellij Community edition is a problem then just setup maven 

To setup Maven locally follow the link here <a href="https://maven.apache.org/install.html">Setup maven locally</a>
<br>
Once setup is complete please run the command inside the downloaded project folder.
<h6>mvn clean install</h6> will run all the test cases that are in the test folder.
<br>
Numerous test cases are added and are self explanatory. 

<h4> Asking RailRoad Questions. </h4>

To ask Rail road question . <b>RailRoadServiceQuestions.java</b> provides a way to input the graph and ask 
typical questions. Technically I could have created a separate properties file to just ask questions but felt that  RailRoadServiceQuestions.java class is quite
self-explanatory and one can easily change the parameter to ask questions like shown below

        //Question-one
        int distanceAlongCertainRoute = railRoadService.computeDistanceAlongCertainRoute("ABC");
        //Question-two(One)
        int stopBasedTrips = railRoadService.numberOfRoutesBetweenTwoTownsByNoOfStops("CC", 3);
        //Question-two(Two)
        int distanceBasedTrips = railRoadService.numberOfRoutesBetweenTwoTownsByDistance("Cc", 30);
        //Question-three
        int shortestRouteByDistanceBetweenTwoTowns = railRoadService.shortestRouteByDistanceBetweenTwoTowns("Cb");

One can easily change the input parameter to test each questions in a seperate run..

Currently, the graph input file (<b>graph_input.txt</b>) is located under resources' folder of src directory (src/resources).
The graph input file is multiline and can take lower case or upper case letters, and the distance has to be less than Integer.MAX_VALUE

To compile and create the jar run <b> mvn clean install </b>
To run the <b>RailRoadServiceQuestions.java</b> use the following command:

<b>java -cp D:\EthicProblemSolution\target\EthicProblemSolution-1.0-SNAPSHOT.jar com.ethic.railroute.solution.RailRoadServiceQuestions</b>

The output will look like below

D:\EthicProblemSolution>java -cp D:\EthicProblemSolution\target\EthicProblemSolution-1.0-SNAPSHOT.jar com.ethic.railroute.solution.RailRoadServiceQuestions
DistanceAlongCertainRoute is : 9 , stopBasedTrips is : 2 , distanceBasedTrips is : 7 , shortestDistanceBetweenTwoTowns : 5

NOTE: mvn command will install the EthicProblemSolution-1.0-SNAPSHOT.jar inside a target location and for me it's in this location (D:\EthicProblemSolution\target\)

